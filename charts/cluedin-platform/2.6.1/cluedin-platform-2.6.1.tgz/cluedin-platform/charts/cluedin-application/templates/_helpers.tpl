{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "cluedin.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 53 chars, so we still have 10 chars to append
because some Kubernetes name fields are limited to 63 chars (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "cluedin.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 53 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- .Release.Name | trunc 53 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
prefix to use for the dns name - defaults to the releasename
*/}}
{{- define "hostnamePrefix" -}}
{{- if .Values.global.dns.prefix -}}
{{- .Values.global.dns.prefix -}}.
{{- end }}
{{- end }}

{{/*
hostname of the application: myrelease.hosted.com
*/}}
{{- define "hostname" -}}
{{ include "hostnamePrefix" . }}{{ .Values.global.dns.hostname }}
{{- end }}

{{/*
hostname for server/auth services myrelease.{{middle}}.hosted.com
*/}}
{{- define "apiUrl" -}}
{{ .Middle }}.{{ template "hostnamePrefix" . }}{{ .Values.global.dns.hostname }}
{{- end }}

{{/*
Main app url e.g. https://app.myrelease.hosted.com
*/}}
{{- define "appFullUrl" -}}
https://{{ .Values.dns.subdomains.app }}.{{ template "hostname" . }}
{{- end }}

{{/*
Output TLS section of ingress
*/}}
{{- define "ingress.tls" -}}
{{- $context := .context -}}
  {{- if or (and $context.Values.global.ingress.tls.hosts $context.Values.global.ingress.tls.secretName) $context.Values.global.ingress.tls.secretName }}
  tls:
  - hosts:
    {{- if $context.Values.global.ingress.tls.hosts }}
    {{- range $context.Values.global.ingress.tls.hosts }}
    - {{ . | quote}}
    {{- end }}
    {{- else }}
    {{- if .prefix }}
    {{- range .prefix }}
    - "{{ . }}.{{ template "hostname" $context }}"
    {{- end }}
    {{- else }}
    - "*.{{ template "hostname" $context }}"
    {{- end }}
    {{- end }}
    secretName: {{ $context.Values.global.ingress.tls.secretName | default "cluedin-frontend-crt" | quote }}
  {{- end }}
{{- end }}

{{- define "protocol" -}}
  {{- if or (and .Values.global.ingress.tls.hosts .Values.global.ingress.tls.secretName) .Values.global.ingress.tls.secretName .Values.global.ingress.forceHttps -}}
  https://
  {{- else -}}
  http://
  {{- end -}}
{{- end -}}

{{- define "protocol.websocket" -}}
  {{- if or (and .Values.global.ingress.tls.hosts .Values.global.ingress.tls.secretName) .Values.global.ingress.tls.secretName .Values.global.ingress.forceHttps -}}
  wss://
  {{- else -}}
  ws://
  {{- end -}}
{{- end -}}

{{- define "features" -}}
{{- $globalVersion := $.Values.global.image.tag -}}
{{- $appVersion := $.Chart.AppVersion -}}
  {{- range $key, $val := .Values.ui.features -}}
      {{- if $val.enabled -}}
          {{- if $val.versionFrom -}}
            {{- if or (semverCompare (printf "~%s" (coalesce $globalVersion $appVersion)) (printf "%s" $val.versionFrom)) (semverCompare (printf "<= %s" (coalesce $globalVersion $appVersion)) (printf "%s" $val.versionFrom))  -}}
                {{$key}};
            {{- end -}}
          {{- else -}}
                {{$key}};
          {{- end -}}
      {{- end -}}
  {{- end -}}
{{- end -}}


{{/*
Return the correct readiness path for the version
{{ include "version.readiness" ( dict "imageRoot" .Values.path.to.the.image "global" $) }}
*/}}
{{- define "version.readiness" -}}
{{- $tag := .imageRoot.tag | toString -}}
{{- if .global }}
    {{- if .global.image }}
    {{- $tag = coalesce .imageRoot.tag .global.image.tag | toString -}}
    {{- end -}}
{{- end -}}
{{- if (semverCompare (printf "^%s" (split "_" $tag)._0) "3.3.0") -}}
/status
{{- else -}}
/ready
{{- end -}}
{{- end -}}

{{- define "cluedin.getsqlconnections" -}}
        - name: MSSQL_HOST
          value: {{ $.Values.sqlserver.host | quote }}
        - name: MSSQL_PORT
          value: {{ $.Values.sqlserver.port | quote }}
        - name: MSSQL_TIMEOUT
          value: {{ $.Values.sqlserver.connectionOptions.timeout | quote }}
{{- $userCheck := dict -}}
{{- range $i, $connection := .Connections }}
{{- if eq $connection.type "mssql" }} 
 {{- if hasKey $.Values.sqlserver.users ($connection.user | toString) }}
  {{- range $key, $user := $.Values.sqlserver.users }}
   {{- if eq $key $connection.user }}
        {{- if not (hasKey $userCheck $user.username) }}
        - name: MSSQL_{{ upper $user.username | replace "-" "" }}_PASSWORD
          valueFrom:
            secretKeyRef:
              name: {{ $user.passwordSecretName }}
              key: {{ $user.passwordSecretKey }}
        {{- $_ := set $userCheck $user.username "true" -}}
        {{- end }}
        - name: {{ printf "%s%s" ($.Prefix | upper) $connection.name | replace "-" "_" | upper | quote }}
          value: {{ printf "Initial Catalog=%s;Data Source=$(MSSQL_HOST),$(MSSQL_PORT);Encrypt=%s;User Id=%s;Password=$(MSSQL_%s_PASSWORD);connection timeout=$(MSSQL_TIMEOUT);%s;%s" $connection.database ($.Values.sqlserver.connectionOptions.encrypt | toString) $user.username (upper $user.username | replace "-" "") $.Values.sqlserver.connectionOptions.extraParameters ($connection.extraConnectionParameters | default "") | quote }}
   {{- end }}
  {{- end }}
 {{- end }}
{{- end }}
{{- end }}
{{- end -}}

{{- define "microservice.getsqlconnections" -}}
{{- $userCheck := dict -}}
{{- range $i, $connection := .Connections }}
{{- if eq $connection.type "mssql" }} 
 {{- if hasKey $.Values.sqlserver.users ($connection.user | toString) }}
  {{- range $key, $user := $.Values.sqlserver.users }}
   {{- if eq $key $connection.user }}
        {{- if not (hasKey $userCheck $user.username) }}
        - name: {{ printf "%sPassword" $connection.name }}
          valueFrom:
            secretKeyRef:
              name: {{ $user.passwordSecretName }}
              key: {{ $user.passwordSecretKey }}
        {{- $_ := set $userCheck $user.username "true" -}}
        {{- end }}
        - name: {{ printf "%sHost" $connection.name | quote }}
          value: {{ $.Values.sqlserver.host | quote }}
        - name: {{ printf "%sPort" $connection.name | quote }}
          value: {{ $.Values.sqlserver.port | quote }}
        - name: {{ printf "%sName" $connection.name | quote }}
          value: {{ $connection.database | quote }}
        - name: {{ printf "%sUserName" $connection.name | quote}}
          value: {{ $user.username | quote }}
        - name: {{ printf "%sEncrypt" $connection.name | quote}}
          value: {{ $.Values.sqlserver.connectionOptions.encrypt | quote }}
   {{- end }}
  {{- end }}
 {{- end }}
{{- end }}
{{- end }}
{{- end -}}

{{- define "getrabbitmqconnections" -}}
{{- $userCheck := dict -}}
{{- range $i, $connection := .Connections }}
{{- if eq $connection.type "rabbitmq" }}
 {{- if hasKey $.Values.rabbitmq.users ($connection.user | toString) }}
  {{- range $key, $user := $.Values.rabbitmq.users }}
   {{- if eq $key $connection.user }}
        {{- if not (hasKey $userCheck $user.username) }}
        - name: RABBITMQ_{{ upper $user.username | replace "-" "" }}_PASSWORD
          valueFrom:
            secretKeyRef:
              name: {{ $user.passwordSecretName }}
              key: {{ $user.passwordSecretKey }}
        {{- $_ := set $userCheck $user.username "true" -}}
        {{- end }}
        - name: {{ printf "%s%s" $.Prefix ($connection.name | replace "-" "_" | upper) | quote }}
        {{- if $connection.isManagement }}
          value: "host={{ $.Values.rabbitmq.host }}:{{ $.Values.rabbitmq.managementPort }};username={{ $user.username}};password=$({{ printf "RABBITMQ_%s_PASSWORD" (upper ($user.username)) }})"
        {{- else }}
          value: "amqp://{{ $user.username}}:$({{ printf "RABBITMQ_%s_PASSWORD" (upper ($user.username)) }})@{{ $.Values.rabbitmq.host }}:{{ $.Values.rabbitmq.port }}"
        {{- end }}
   {{- end }}
  {{- end }}
 {{- end }}
{{- end }}
{{- end }}
{{- end -}}

{{- define "getneo4jconnections" -}}
{{- $userCheck := dict -}}
{{- range $i, $connection := .Connections }}
{{- if eq $connection.type "neo4j" }}
 {{- if hasKey $.Values.neo4j.users ($connection.user | toString) }}
  {{- range $key, $user := $.Values.neo4j.users }}
   {{- if eq $key $connection.user }}
        {{- if not (hasKey $userCheck $user.username) }}
        - name: NEO4J_{{ upper $user.username | replace "-" "" }}_PASSWORD
          valueFrom:
            secretKeyRef:
              name: {{ $user.passwordSecretName }}
              key: {{ $user.passwordSecretKeyEncoded }}
        {{- $_ := set $userCheck $user.username "true" -}}
        {{- end }}
        - name: {{ printf "%s%s" ($.Prefix | upper) ($connection.name | replace "-" "_" | upper) | quote }}
          value: "http://{{ $user.username}}:$({{ printf "NEO4J_%s_PASSWORD" (upper ($user.username)) }})@{{ $.Values.neo4j.host }}:{{ $.Values.neo4j.httpPort }}"
   {{- end }}
  {{- end }}
 {{- end }}
{{- end }}
{{- end }}
{{- end -}}

{{- define "getredisconnections" -}}
{{- $userCheck := dict -}}
{{- range $i, $connection := .Connections }}
{{- if eq $connection.type "redis" }}
 {{- if hasKey $.Values.redis.users ($connection.user | toString) }}
  {{- range $key, $user := $.Values.redis.users }}
   {{- if eq $key $connection.user }}
        {{- if not (hasKey $userCheck $connection.user) }}
        - name: REDIS_{{ upper $connection.user | replace "-" "" }}_PASSWORD
          valueFrom:
            secretKeyRef:
              name: {{ $user.passwordSecretName }}
              key: {{ $user.passwordSecretKey }}
        {{- $_ := set $userCheck $connection.user "true" -}}
        {{- end }}
        - name: {{ printf "%s%s" ($.Prefix | upper) ($connection.name | replace "-" "_" | upper) | quote }}
          value: "{{ $.Values.redis.host }}:{{ $.Values.redis.port }},password=$({{ printf "REDIS_%s_PASSWORD" (upper ($connection.user)) }}),ssl={{ $.Values.redis.connectionOptions.encrypt}},abortConnect={{ $connection.abortConnect | default false }},connectRetry={{ $connection.connectRetry | default 0 }},connectTimeout={{ $connection.connectTimeout | default 20000 }},syncTimeout={{ $connection.syncTimeout | default 20000 }},keepAlive={{ $connection.keepAlive | default 30 }}"
   {{- end }}
  {{- end }}
 {{- end }}
{{- end }}
{{- end }}
{{- end -}}

{{- define "getelasticsearchconnections" -}}
{{- $userCheck := dict -}}
{{- range $i, $connection := .Connections }}
{{- if eq $connection.type "elasticsearch" }}
 {{- if hasKey $.Values.elasticsearch.users ($connection.user | toString) }}
  {{- range $key, $user := $.Values.elasticsearch.users }}
   {{- if eq $key $connection.user }}
        {{- if not (hasKey $userCheck $connection.user) }}
        - name: ELASTICSEARCH_{{ upper $connection.user | replace "-" "" }}_PASSWORD
          valueFrom:
            secretKeyRef:
              name: {{ $user.passwordSecretName }}
              key: {{ $user.passwordSecretKey }}
        {{- $_ := set $userCheck $connection.user "true" -}}
        {{- end }}
        - name: {{ printf "%s%s" ($.Prefix | upper) ($connection.name | replace "-" "_" ) | quote }}
          value: "http://{{ $user.username}}:$({{ printf "ELASTICSEARCH_%s_PASSWORD" (upper ($connection.user)) }})@{{ $.Values.elasticsearch.host }}:{{ $.Values.elasticsearch.port }}"
   {{- end }}
  {{- end }}
 {{- end }}
{{- end }}
{{- end }}
{{- end -}}

{{- define "cluedin.ingress.annotations" -}}
{{- with .Values.global.ingress.annotations }}
{{- toYaml . | nindent 4 }}
{{- end }}
{{- end -}}

{{- define "cluedin.ingress.spec" -}}
{{- with .Values.global.ingress.spec }}
{{- toYaml . | nindent 2 }}
{{- end }}
{{- end -}}

{{/*
Format resource value (with Ki/Mi/G suffix) as float value.
Based on https://github.com/helm/helm/issues/11376#issuecomment-1256831105
*/}}
{{- define "util.resource-to-float" -}}
    {{- $value := . -}}
    {{- $unit := 1.0 -}}
    {{- if typeIs "string" . -}}
        {{- $base2 := dict "Ki" 0x1p10 "Mi" 0x1p20 "Gi" 0x1p30 "Ti" 0x1p40 "Pi" 0x1p50 "Ei" 0x1p60 -}}
        {{- $base10 := dict "m" 1e-3 "k" 1e3 "M" 1e6 "G" 1e9 "T" 1e12 "P" 1e15 "E" 1e18 -}}
        {{- range $k, $v := merge $base2 $base10 -}}
            {{- if hasSuffix $k $ -}}
                {{- $value = trimSuffix $k $ -}}
                {{- $unit = $v -}}
            {{- end -}}
        {{- end -}}
    {{- end -}}
    {{- printf "%.3f" (mulf (float64 $value) $unit) | quote -}}
{{- end -}}