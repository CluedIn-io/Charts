{{- define "neo4j.cluedin.pluginInstaller" }}
{{- if .Values.cluedinExtensions.pluginInstallers }}
{{- if .Values.cluedinExtensions.pluginInstallersEnabled }}
{{- range $key, $plugin := .Values.cluedinExtensions.pluginInstallers }}
name: {{ $key }}
{{- if $.Values.global.image.registry }}
image: "{{ $.Values.global.image.registry }}/{{ $plugin.image.repository }}:{{ $plugin.image.tag }}"
{{- else }}
image: "{{ $plugin.image.repository }}:{{ $plugin.image.tag }}"
{{- end }}
imagePullPolicy: "IfNotPresent"
{{- if $.Values.securityContext }}
securityContext: {{ $.Values.containerSecurityContext | toYaml | nindent 2 }}
{{- end }}
volumeMounts:
  - name: plugins
    mountPath: /plugins
command:
  - "/bin/sh"
  - "-c"
  - |
    cd /tmp
    curl --location --remote-name {{ printf "%s/%s" $plugin.downloadUrl $plugin.fileName }}
    cp {{ $plugin.fileName }} {{ $plugin.target }}

resources:
  requests:
    cpu: '100m'
    memory: '100M'
  limits:
    cpu: '100m'
    memory: '100M'
{{- end }}
{{- end }}
{{- end }}
{{- end }}
