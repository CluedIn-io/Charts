{{/* vim: set filetype=mustache: */}}
{{/*
Return the proper image name
{{ include "common.images.image" ( dict "imageRoot" .Values.path.to.the.image "global" $) }}
*/}}
{{- define "common.images.image" -}}
{{- $registryName := .imageRoot.registry -}}
{{- if .global }}
    {{- if .global.image }}
    {{- $registryName = coalesce .imageRoot.registry .global.image.registry -}}
    {{- end -}}
{{- end -}}
{{- $repositoryName := .imageRoot.repository -}}
{{- $tag := .imageRoot.tag | toString -}}
{{- if .global }}
    {{- if .global.image }}
    {{- $tag = coalesce .imageRoot.tag .global.image.tag | toString -}}
    {{- end -}}
{{- end -}}
{{- if $registryName }}
{{- printf "%s/%s:%s" $registryName $repositoryName $tag -}}
{{- else -}}
{{- printf "%s:%s" $repositoryName $tag -}}
{{- end -}}
{{- end -}}

{{/*
Return the proper Docker Image Registry Secret Names
{{ include "common.images.renderGlobalPullSecrets" ( dict "context" $) }}
*/}}
{{- define "common.images.renderGlobalPullSecrets" -}}
  {{- $pullSecrets := list }}
  {{- $context := .context }}

  {{- if $context.Values.global }}
    {{- range $context.Values.global.imagePullSecrets -}}
      {{- $pullSecrets = append $pullSecrets .name -}}
    {{- end -}}
  {{- end -}}

  {{- if (not (empty $pullSecrets)) -}}
imagePullSecrets:
    {{- range $pullSecrets }}
  - name: {{ . }}
    {{- end }}
  {{- end -}}

{{- end -}}

{{/*
This is added to overwrite common.images.renderPullSecrets from bitnami common charts https://github.com/bitnami/charts/blob/5fb0e97d9336d40d86c3295637d4233218b8afea/bitnami/common/templates/_images.tpl#L69. 
As it is causing issues to redis and Rabbitmq latest chart when we use below configuration in our values

global:
  imagePullSecrets:
    - name: acr-key

It only will work if we use below configuration:

global:
  imagePullSecrets:
    - acr-key

But as most of the helm chart require us to configure our global imagepullsecret like in the first one, 
we need to overwrite it so it can work for redis and rabbitmq aswell.

It will follow exactly as common.images.renderGlobalPullSecrets above.
This is to ensure consistent logic for rendering global pull secret.

Return the proper Docker Image Registry Secret Names
{{ include "common.images.renderPullSecrets" ( dict "context" $) }}
*/}}
{{- define "common.images.renderPullSecrets" -}}
  {{- $pullSecrets := list }}
  {{- $context := .context }}

  {{- if $context.Values.global }}
    {{- range $context.Values.global.imagePullSecrets -}}
      {{- $pullSecrets = append $pullSecrets .name -}}
    {{- end -}}
  {{- end -}}

  {{- if (not (empty $pullSecrets)) -}}
imagePullSecrets:
    {{- range $pullSecrets }}
  - name: {{ . }}
    {{- end }}
  {{- end -}}

{{- end -}}

{{/*
Return the current version
{{ include "common.images.version" ( dict "imageRoot" .Values.path.to.the.image "global" $) }}
*/}}
{{- define "common.images.version" -}}
{{- $tag := .imageRoot.tag | toString -}}
{{- if .global }}
    {{- if .global.image }}
    {{- $tag = coalesce .imageRoot.tag .global.image.tag | toString -}}
    {{- end -}}
{{- end -}}
{{- printf "%s" $tag -}}
{{- end -}}