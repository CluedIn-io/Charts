{{/* vim: set filetype=mustache: */}}

{{/*
Render list of wait init containers
{{ include "common.wait.renderWaitContainers" (dict "list" path.to.wait.section "context" $) }}
*/}}
{{- define "common.wait.renderWaitContainers" -}}
{{- $context := .context -}}
{{- range .list }}
{{- include "common.wait.single" (dict  "name" .name "type" .type "context" $context) }}
{{ end -}}
{{- end -}}

{{/*
Render single wait initContainer
{{ include "common.wait.single" (dict "name" "cluedin-seq" "type" "service" "context" $) }}
*/}}
{{- define "common.wait.single" -}}
{{- $context := .context -}}
- name: wait-{{ .name }}
  securityContext:
    seccompProfile:
      type: RuntimeDefault
    capabilities:
      drop:
        - ALL
    runAsNonRoot: true
    runAsUser: 10001
    runAsGroup: 10001
    allowPrivilegeEscalation: false
    readOnlyRootFilesystem: true
  image: "{{ template "common.images.image" ( dict "imageRoot" $context.Values.global.containerImages.wait.image "global" $context.Values.global) }}"
  imagePullPolicy: {{ $context.Values.global.containerImages.wait.image.pullPolicy | default "IfNotPresent"}}
  args:
    - "{{ .type }}"
    - "{{ .name }}"
    - "-n"
    - "{{ $context.Release.Namespace }}"
{{- end -}}

