{{/* vim: set filetype=mustache: */}}

{{/*
Prefix to use for the dns name - defaults to the releasename
*/}}
{{- define "hostnamePrefix" -}}
{{- if .Values.global.dns.prefix -}}
{{- .Values.global.dns.prefix -}}.
{{- end }}
{{- end }}

{{/*
Hostname of the application: myrelease.hosted.com
*/}}
{{- define "hostname" -}}
{{ include "hostnamePrefix" . }}{{ .Values.global.dns.hostname }}
{{- end }}

