
{{/*
Render secret-store volume
{{- include "cluedin-common.keyvault.volumes" (dict "root" . "key" "cluedin-redis") | nindent 8 }}
*/}}
{{- define "cluedin-common.keyvault.volumes" -}}
{{- $key := .key -}}
{{- if and .root.Values.global.keyvault.enabled (hasKey .root.Values.global.keyvault.secretProviderClasses $key) -}}
- name: azure-keyvault-secrets
  csi:
    driver: secrets-store.csi.k8s.io
    readOnly: true
    volumeAttributes:
      secretProviderClass: {{ printf "%s-sync" $key | quote }}
{{- end -}}
{{- end -}}

{{/*
Render secret-store volumeMounts
{{- include "cluedin-common.keyvault.volumes" (dict "root" . "key" "cluedin-redis") | nindent 8 }}
*/}}
{{- define "cluedin-common.keyvault.volumeMounts" -}}
{{- $key := .key -}}
{{- if and .root.Values.global.keyvault.enabled (hasKey .root.Values.global.keyvault.secretProviderClasses $key) -}}
- name: azure-keyvault-secrets
  mountPath: /mnt/secrets-sync
  readOnly: true
{{- end -}}
{{- end -}}
