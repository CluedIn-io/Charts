{{/* vim: set filetype=mustache: */}}

{{/*
Return a topologyKey definition
{{ include "common.affinities.topologyKey" (dict "topologyKey" "BAR") -}}
*/}}
{{- define "common.affinities.topologyKey" -}}
{{ .topologyKey | default "kubernetes.io/hostname" -}}
{{- end -}}

{{/*
Return a soft podAffinity/podAntiAffinity definition
{{ include "cluedin.affinities.pods" (dict "key" "FOO" "values" (list "BAR" "BAZ")) -}}
*/}}
{{- define "cluedin.affinities.pods" -}}
preferredDuringSchedulingIgnoredDuringExecution:
  - podAffinityTerm:
      labelSelector:
        matchExpressions:
        - key: {{ .key }}
          operator: In
          values:
          {{- range .values }}
          - {{ . | quote }}
          {{- end }}
      topologyKey: {{ include "common.affinities.topologyKey" (dict "topologyKey" .topologyKey) }}
    weight: 1
{{- end -}}

{{/*
Return a nodeAffinity definition
{{- tpl (include "cluedin.affinities.node" .) . | nindent 8 }}
*/}}
{{- define "cluedin.affinities.node" -}}
nodeAffinity:
  preferredDuringSchedulingIgnoredDuringExecution:
  - weight: 1
    preference:
      matchExpressions:
      - key: topology.kubernetes.io/zone
        operator: In
        values:
        - {{ .Values.global.zone | quote }}
{{- end -}}
