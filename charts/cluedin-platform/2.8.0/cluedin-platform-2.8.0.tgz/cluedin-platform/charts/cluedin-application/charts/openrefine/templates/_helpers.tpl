{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "openrefine.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "openrefine.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "openrefine.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "openrefine.labels" -}}
helm.sh/chart: {{ include "openrefine.chart" . }}
{{ include "openrefine.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "openrefine.selectorLabels" -}}
app.kubernetes.io/name: {{ include "openrefine.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "openrefine.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "openrefine.fullname" .) (tpl .Values.serviceAccount.name .) }}
{{- else }}
{{- default (tpl .Values.serviceAccount.name .) }}
{{- end }}
{{- end }}

{{/*
Prefix to use for the dns name - defaults to the releasename
*/}}
{{- define "hostnamePrefix" -}}
{{- if .Values.global.dns.prefix -}}
{{- .Values.global.dns.prefix -}}.
{{- end }}
{{- end }}

{{/*
Hostname of the application: myrelease.hosted.com
*/}}
{{- define "hostname" -}}
{{ include "hostnamePrefix" . }}{{ .Values.global.dns.hostname }}
{{- end }}

{{/*
Output TLS section of ingress
*/}}
{{- define "ingress.tls" -}}
  {{- if or (and .Values.global.ingress.tls.hosts .Values.global.ingress.tls.secretName) .Values.global.ingress.tls.secretName }}
  tls:
  - hosts:
    {{- if .Values.global.ingress.tls.hosts }}
    {{- range .Values.global.ingress.tls.hosts }}
    - {{ . | quote}}
    {{- end }}
    {{- else }}
    - "*.{{ template "hostname" . }}"
    {{- end }}
    secretName: {{ .Values.global.ingress.tls.secretName | default "cluedin-frontend-crt" | quote }}
  {{- end }}
{{- end }}

