# CluedIn Platform

Welcome to CluedIn Platform !

## Parameters

### Global parameters

| Name                      | Description                                                            | Value |
| ------------------------- | ---------------------------------------------------------------------- | ----- |
| `global.image.registry`   | Global container image registry.                                       | `""`  |
| `global.image.tag`        | Global Docker image tag. If blank will default to `.Chart.AppVersion`. | `""`  |
| `global.image.pullPolicy` | Global image pull policy.                                              | `""`  |


### Platform parameters

| Name                               | Description                                                         | Value |
| ---------------------------------- | ------------------------------------------------------------------- | ----- |
| `platform.extraSecrets`            | Optionally specify extra secrets to be created by the chart.        | `{}`  |
| `platform.extraImagePullSecrets`   | Optionally create extra imagePullSecrets for private registries.    | `{}`  |
| `platform.extraCertificateSecrets` | Optionally create extra TLS secrets. Values must be BASE64 encoded. | `{}`  |


### Application parameters

| Name | Description | Value |
| ---- | ----------- | ----- |


### Infrastructure parameters

| Name | Description | Value |
| ---- | ----------- | ----- |


