{{/*
Expand the name of the chart.
*/}}
{{- define "rabbitmq.name" -}}
{{- include "cloudpirates.name" . -}}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "rabbitmq.fullname" -}}
{{- include "cloudpirates.fullname" . -}}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "rabbitmq.chart" -}}
{{- include "cloudpirates.chart" . -}}
{{- end }}

{{/*
Common labels
*/}}
{{- define "rabbitmq.labels" -}}
{{/* ----- CluedIn Customization Start ----- */}}
{{- $labels := include "cloudpirates.labels" . | fromYaml -}}
{{- with .Values.commonLabels -}}
{{- $labels = merge (include "cloudpirates.tplvalues.render" (dict "value" . "context" $) | fromYaml) $labels -}}
{{- end -}}
{{- toYaml $labels -}}
{{/* ----- CluedIn Customization End ----- */}}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "rabbitmq.selectorLabels" -}}
{{- include "cloudpirates.selectorLabels" . -}}
{{- end }}

{{/*
Common annotations
*/}}
{{- define "rabbitmq.annotations" -}}
{{- include "cloudpirates.annotations" . -}}
{{- end }}

{{/*
Get the secret name for RabbitMQ credentials
*/}}
{{- define "rabbitmq.secretName" -}}
{{- if .Values.auth.existingSecret }}
{{- include "cloudpirates.tplvalues.render" (dict "value" .Values.auth.existingSecret "context" .) }}
{{- else }}
{{- include "rabbitmq.fullname" . }}
{{- end }}
{{- end }}

{{/*
Get the secret key for RabbitMQ password
*/}}
{{- define "rabbitmq.secretPasswordKey" -}}
{{- if .Values.auth.existingPasswordKey }}
{{- .Values.auth.existingPasswordKey }}
{{- else }}password
{{- end }}
{{- end }}

{{/*
Get the secret key for Erlang cookie
*/}}
{{- define "rabbitmq.secretErlangCookieKey" -}}
{{- if .Values.auth.existingErlangCookieKey }}
{{- .Values.auth.existingErlangCookieKey }}
{{- else }}erlang-cookie
{{- end }}
{{- end }}

{{/*
Return the proper RabbitMQ image name
*/}}
{{- define "rabbitmq.image" -}}
{{/* ----- CluedIn Customization Start ----- */}}
{{- include "common.images.image" (dict "imageRoot" .Values.image "global" .Values.global) -}}
{{/* ----- CluedIn Customization End ----- */}}
{{- end }}

{{/*
Return the proper RabbitMQ init container image name
*/}}
{{- define "rabbitmq.initContainer.image" -}}
{{/* ----- CluedIn Customization Start ----- */}}
{{- $image := dict
      "registry" (coalesce .Values.initContainer.image.registry .Values.image.registry)
      "repository" (coalesce .Values.initContainer.image.repository .Values.image.repository)
      "tag" (coalesce .Values.initContainer.image.tag .Values.image.tag) -}}
{{- include "common.images.image" (dict "imageRoot" $image "global" .Values.global) -}}
{{/* ----- CluedIn Customization End ----- */}}
{{- end }}

{{/*
Return the proper RabbitMQ definitions auto-reload image name
*/}}
{{- define "rabbitmq.definitions.autoReload.image" -}}
{{- include "cloudpirates.image" (dict "image" .Values.definitions.autoReload.image "global" .Values.global) -}}
{{- end }}

{{/*
Return the proper Docker Image Registry Secret Names
*/}}
{{- define "rabbitmq.imagePullSecrets" -}}
{{ include "cloudpirates.images.renderPullSecrets" (dict "images" (list .Values.image) "context" .) }}
{{- end -}}

{{- define "rabbitmq.serviceAccountName" -}}
    {{- if .Values.serviceAccount.create -}}
        {{- default (include "rabbitmq.fullname" .) .Values.serviceAccount.name }}
    {{- else -}}
        {{- default "default" .Values.serviceAccount.name -}}
    {{- end -}}
{{- end -}}

{{/*
Extract plugin name from plugin URL
*/}}
{{- define "rabbitmq.pluginName" -}}
{{- $url := . -}}
{{- $filename := (regexReplaceAll ".*/" $url "") -}}
{{- $filename = (regexReplaceAll "-[0-9]+\\.[0-9]+\\.[0-9]+.*" $filename "") -}}
{{- $filename -}}
{{- end -}}
